"""Current version of package silence_tensorflow"""
__version__ = "1.0.2"