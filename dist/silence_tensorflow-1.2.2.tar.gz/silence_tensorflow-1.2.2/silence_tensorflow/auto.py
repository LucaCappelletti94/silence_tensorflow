"""Submodule for automatic application on import."""

from silence_tensorflow.silence_tensorflow import silence_tensorflow

silence_tensorflow()
