"""Current version of package silence_tensorflow."""
__version__ = "1.2.2"
