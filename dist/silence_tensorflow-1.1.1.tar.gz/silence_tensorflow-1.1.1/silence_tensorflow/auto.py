from .silence_tensorflow import silence_tensorflow

silence_tensorflow()