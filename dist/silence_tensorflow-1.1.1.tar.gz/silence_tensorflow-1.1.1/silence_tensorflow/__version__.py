"""Current version of package silence_tensorflow"""
__version__ = "1.1.1"